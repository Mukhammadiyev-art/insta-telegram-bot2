import os
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.utils import executor
import requests

API_TOKEN = os.getenv("BOT_TOKEN", "PASTE_YOUR_BOT_TOKEN_HERE")
logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=["start", "help"])
async def send_welcome(message: Message):
    await message.answer("Instagram yuklovchi botga xush kelibsiz! Havola yuboring:")

@dp.message_handler()
async def handle_instagram_link(message: Message):
    url = message.text.strip()
    if "instagram.com" not in url:
        await message.answer("Iltimos, to‘g‘ri Instagram havolasini yuboring.")
        return

    try:
        await message.answer("⏬ Yuklanmoqda...")
        response = requests.get(f"https://saveig.app/api/ajaxSearch", params={"q": url})
        if response.ok:
            result_url = response.json().get("links", [])[0].get("url", "")
            if result_url:
                await message.answer_video(result_url)
            else:
                await message.answer("Media topilmadi yoki yuklab bo‘lmadi.")
        else:
            await message.answer("Xatolik yuz berdi. Qayta urinib ko‘ring.")
    except Exception as e:
        await message.answer(f"Xatolik: {e}")

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
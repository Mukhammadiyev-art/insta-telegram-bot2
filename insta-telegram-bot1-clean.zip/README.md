# Instagram Downloader Telegram Bot

Telegram bot that downloads Instagram posts, reels, and stories from links and sends them directly in chat.

## Features
- Download photos, videos, reels
- Simple usage: just send an Instagram link